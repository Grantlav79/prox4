### Features

* `tzdata` is installed by default in the container image, and the time zone can be set using the `TZ` environment variable.
* The `quic-bind-port` command line parameter is supported in frps, which specifies the port for accepting frpc connections using the QUIC protocol.