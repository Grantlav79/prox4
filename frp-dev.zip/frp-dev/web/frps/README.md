# frps-dashboard

## Project Setup

```sh
yarn install
```

### Compile and Hot-Reload for Development

```sh
make dev
```

### Type-Check, Compile and Minify for Production

```sh
make build
```

### Lint with [ESLint](https://eslint.org/)

```sh
make lint
```
